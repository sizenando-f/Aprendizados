Nome: Sizenando Souza França
RGM: 50575

Comando para compilar:
make

Comando para executar o servidor:
./servidor <porta>

Comando para executar o cliente:
./cliente <ip/nome> <porta>

Exemplos de entrada no cliente:
D 101 2 4899 -22.221 -54.812
P 102 2 10 -22.220 -54.810
